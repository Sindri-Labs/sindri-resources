# Sudoku Circuit


This circuit accepts a (public) sudoku puzzle and a (private) solution to that puzzle.  Both are formatted as 81-long integer lists with entries 1-9.  

Source: https://github.com/web3-master/zksnark-sudoku