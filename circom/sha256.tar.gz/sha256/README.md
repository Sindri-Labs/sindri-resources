# SHA256

This circuit computes the hash of an input list of length 32.