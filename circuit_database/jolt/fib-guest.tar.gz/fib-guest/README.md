# Jolt Fibonacci Guest Code

This guest code is adapted from the fibonacci example in the Jolt [repository](https://github.com/a16z/jolt/tree/main/examples/fibonacci/guest) with added components to make it compatible with Sindri. The guest function inputs and outputs are replaced with generic `Input` and `Output` structs, which are defined in `utils.rs`