# multiplier2

This circuit checks that `c` is the multiplication of `a` and `b`.

Source (March 12, 2023): 
https://docs.circom.io/getting-started/writing-circuits/
https://docs.circom.io/getting-started/compiling-circuits/