# Billion ZK Voters

This circuit is from `jordan-public`'s award-winning [Billion Secret Voters project](https://github.com/jordan-public/billion-zk-voters).  Note that this is the circuit allowing one to cast their vote, see the linked repository for more Noir sample circuits that perform the other required functions for this end-to-end massively scalable ZK-voting protocol.

