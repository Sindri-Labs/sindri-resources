# Hello World for Noir

This circuit was adapted from [Noir's getting started guide](https://noir-lang.org/getting_started/hello_world) and creates a proof that `x!=y`.