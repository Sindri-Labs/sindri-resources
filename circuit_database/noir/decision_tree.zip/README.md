# Decision Tree Noir Circuit

This circuit is from [StorSwift's ZKML project](https://github.com/storswiftlabs/zkml-noir).  It features a pretrained decision tree of maximum depth 3.  For any input vector, the output of the circuit is the leaf value, or prediction from that input.
