# Quadratic

This circuit computes $x^2+72$ with $x$ a public input.  It was adapted from one of the examples provided by Axiom's Halo2 Scaffold repository: https://github.com/axiom-crypto/halo2-scaffold.