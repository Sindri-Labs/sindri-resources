# Gnark Exponentiate

This is another circuit from the [Gnark Github Examples](https://github.com/Consensys/gnark/blob/master/examples/exponentiate/exponentiate.go).  It checks that $y == x**e$ where $e$ is private.