# Poseidon

This circuit was adapted from [Vocdoni's Gnark Primitives](https://github.com/vocdoni/gnark-crypto-primitives/tree/main) and computes the Poseidon hash of a preimage.