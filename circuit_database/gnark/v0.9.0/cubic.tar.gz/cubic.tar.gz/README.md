# Gnark Cubic

This circuit is the standard for [Gnark beginners](https://github.com/Consensys/gnark/blob/master/examples/cubic/cubic.go). It checks $x^3 + x + 5 == y$ for public $y$ and private $x$.