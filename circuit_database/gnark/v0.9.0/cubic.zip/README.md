# Gnark Cubic
